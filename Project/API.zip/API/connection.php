<?php
    define('HOST','localhost');
    define('USER','id22020617_ewishes');
    define('DB','id22020617_prakruti');
    define('PASS','Tops@123456');
    
    $con=mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');
?>