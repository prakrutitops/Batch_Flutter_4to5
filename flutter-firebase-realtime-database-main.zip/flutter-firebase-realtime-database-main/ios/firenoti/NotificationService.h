//
//  NotificationService.h
//  firenoti
//
//  Created by Kamal Bunkar  on 18/09/21.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
