# Flutter Firebase Realtime Database

## Learn How to Integrate Firebase Realtime Database in Flutter Project.

![flutter- transparent black](https://user-images.githubusercontent.com/32509412/135740666-0406208b-a96d-48cf-8211-9df44aab3f37.png)

![firebase-database](https://user-images.githubusercontent.com/32509412/135740715-b452b08d-f4f2-48ac-8499-bc4b6ecc9608.png)


All CRUD operations are included in this demo project.

Also any change made on realtime database will reflect on all the devices and on all the platform.

If you have any questions OR doubts, [Feel free to contact me](https://www.dripcoding.com/flutter-firebase-realtime-database/)




https://user-images.githubusercontent.com/32509412/135739517-809da0ae-6f67-4409-8699-ee5cc20fbe85.mp4

