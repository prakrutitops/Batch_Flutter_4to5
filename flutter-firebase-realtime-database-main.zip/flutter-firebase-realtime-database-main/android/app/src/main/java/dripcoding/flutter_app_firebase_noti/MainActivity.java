package dripcoding.flutter_app_firebase_noti;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
